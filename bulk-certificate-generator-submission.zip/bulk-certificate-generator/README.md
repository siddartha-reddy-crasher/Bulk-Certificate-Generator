# Bulk Certificate Generator

A submission-ready backend API for generating certificates in bulk.

## Tech Stack

- Python 3.11+
- FastAPI
- SQLite + SQLAlchemy
- ReportLab
- Pytest

## Why background processing?

A bulk request can contain hundreds or thousands of recipients. Generating every PDF before returning the HTTP response would make the request slow and vulnerable to timeouts.

This implementation creates a job immediately and processes recipients in the background. The client can poll the job status endpoint to monitor progress.

Each recipient is processed independently. If one certificate fails, the remaining valid recipients continue processing.

## Project Structure

```text
bulk-certificate-generator/
├── app/
│   ├── api/
│   │   ├── jobs.py
│   │   └── certificates.py
│   ├── services/
│   │   ├── certificate_generator.py
│   │   └── job_processor.py
│   ├── database.py
│   ├── main.py
│   ├── models.py
│   └── schemas.py
├── generated/
├── tests/
├── requirements.txt
└── README.md
```

## Setup

### 1. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

## Run the application

```bash
uvicorn app.main:app --reload
```

Open:

- API: http://127.0.0.1:8000
- Swagger UI: http://127.0.0.1:8000/docs

## Create a certificate generation job

```bash
curl -X POST "http://127.0.0.1:8000/jobs" \
  -H "Content-Type: application/json" \
  -d '{
    "event_name": "Python Workshop 2026",
    "event_date": "2026-10-07",
    "recipients": [
      {
        "name": "Siddartha Reddy",
        "email": "siddhu@example.com",
        "certificate_title": "Certificate of Participation"
      },
      {
        "name": "Akshay Kumar",
        "email": "akshay@example.com",
        "certificate_title": "Certificate of Participation"
      }
    ]
  }'
```

The API returns a `job_id`.

## Check job status

```bash
curl "http://127.0.0.1:8000/jobs/{job_id}"
```

Example:

```json
{
  "job_id": "8c5c...",
  "status": "COMPLETED",
  "total": 2,
  "completed": 2,
  "successful": 2,
  "failed": 0,
  "progress_percent": 100.0,
  "recipients": [
    {
      "id": "...",
      "name": "Siddartha Reddy",
      "email": "siddhu@example.com",
      "status": "SUCCESS",
      "error_message": null,
      "certificate_id": "..."
    }
  ]
}
```

Possible job statuses:

- `PENDING`
- `PROCESSING`
- `COMPLETED`
- `COMPLETED_WITH_ERRORS`
- `FAILED`

## Retrieve a generated certificate

Use the certificate ID returned in the job response:

```text
GET /certificates/{certificate_id}
```

The endpoint returns the generated PDF.

## Validation and failure handling

The API validates:

- Recipient name is present and has at least two characters.
- Email address is valid.
- Certificate title is non-empty.
- Event name is non-empty.
- Event date is a valid date.
- A job contains at least one recipient.

A certificate generation exception is caught per recipient. The failed recipient is marked `FAILED` with an error message, while other recipients continue.

If at least one recipient fails, the final job status is `COMPLETED_WITH_ERRORS`.

## Testing

Run all tests:

```bash
pytest -v
```

The tests cover:

1. Creating a generation job.
2. Input validation.
3. Certificate PDF generation.
4. Job status and progress.
5. Individual certificate failure isolation.
6. Generated certificate retrieval.
7. Missing job handling.

## Design decisions

### FastAPI

FastAPI provides automatic request validation, OpenAPI documentation, and good performance with a small amount of code.

### SQLite

SQLite keeps the project easy to run locally and satisfies the relational database requirement. For production, the database URL can be changed to PostgreSQL without changing the API contract.

### SQLAlchemy

SQLAlchemy separates database operations from the API layer and makes the application easier to migrate to another relational database.

### ReportLab

ReportLab generates PDF certificates without requiring an external office application.

### BackgroundTasks

FastAPI's background task mechanism is sufficient for this assignment because it demonstrates asynchronous job processing without adding operational complexity. For very large production workloads, the processor could be moved to Celery/RQ with Redis or another durable queue.

## Interview discussion points

### How would you scale this?

Move job processing from FastAPI's in-process background task to a durable queue such as Celery + Redis/RabbitMQ. Run multiple workers and keep certificate files in object storage such as S3.

### What happens if the server restarts?

The current assignment implementation uses in-process background tasks, so an active task could be interrupted. The database preserves the job and recipient state. A production implementation should use a durable queue and a retry mechanism.

### Why not one API request per certificate?

Bulk processing reduces HTTP overhead and lets the client track the entire operation using one job ID.

### How are partial failures handled?

Each recipient has an independent status. One failure is recorded and processing continues for the remaining recipients.

## License

For interview/assessment submission use.
