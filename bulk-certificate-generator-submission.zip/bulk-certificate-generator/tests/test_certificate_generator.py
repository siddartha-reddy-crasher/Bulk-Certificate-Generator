from pathlib import Path

from app.services.certificate_generator import generate_certificate


def test_certificate_generation(tmp_path, monkeypatch):
    import app.services.certificate_generator as generator

    monkeypatch.setattr(generator, "OUTPUT_DIR", tmp_path)

    path = generate_certificate(
        certificate_id="test-cert",
        recipient_name="Test User",
        certificate_title="Certificate of Participation",
        event_name="Testing Event",
        event_date="2026-10-07",
    )

    assert Path(path).exists()
    assert Path(path).stat().st_size > 0
