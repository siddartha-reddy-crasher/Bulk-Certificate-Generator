from app.models import GenerationJob, RecipientStatus
from app.services import job_processor


def test_individual_certificate_failure_is_isolated(client, monkeypatch):
    original = job_processor.generate_certificate
    calls = {"count": 0}

    def flaky_generator(*args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            raise RuntimeError("Intentional test failure")
        return original(*args, **kwargs)

    monkeypatch.setattr(job_processor, "generate_certificate", flaky_generator)

    payload = {
        "event_name": "Failure Isolation Test",
        "event_date": "2026-10-07",
        "recipients": [
            {
                "name": "Failing User",
                "email": "fail@example.com",
                "certificate_title": "Participation",
            },
            {
                "name": "Valid User",
                "email": "valid@example.com",
                "certificate_title": "Participation",
            },
        ],
    }

    response = client.post("/jobs", json=payload)
    job_id = response.json()["job_id"]

    # Run processor directly for deterministic unit-test behavior.
    job_processor.process_job(job_id)

    result = client.get(f"/jobs/{job_id}").json()
    assert result["status"] == "COMPLETED_WITH_ERRORS"
    assert result["successful"] == 1
    assert result["failed"] == 1
    assert result["progress_percent"] == 100.0
    assert any(r["status"] == "FAILED" for r in result["recipients"])
    assert any(r["status"] == "SUCCESS" for r in result["recipients"])
