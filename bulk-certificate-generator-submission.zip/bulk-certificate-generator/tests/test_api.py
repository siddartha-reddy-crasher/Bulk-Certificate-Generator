import time

from app.models import GenerationJob, RecipientStatus


def sample_payload():
    return {
        "event_name": "Python Workshop",
        "event_date": "2026-10-07",
        "recipients": [
            {
                "name": "Siddartha Reddy",
                "email": "siddhu@example.com",
                "certificate_title": "Certificate of Participation",
            },
            {
                "name": "Akshay Kumar",
                "email": "akshay@example.com",
                "certificate_title": "Certificate of Participation",
            },
        ],
    }


def wait_for_completion(client, job_id, timeout=5):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = client.get(f"/jobs/{job_id}").json()
        if last["status"] in {"COMPLETED", "COMPLETED_WITH_ERRORS", "FAILED"}:
            return last
        time.sleep(0.05)
    return last


def test_create_generation_job(client):
    response = client.post("/jobs", json=sample_payload())
    assert response.status_code == 202
    data = response.json()
    assert data["total"] == 2
    assert data["status"] in {"PENDING", "PROCESSING", "COMPLETED"}


def test_input_validation(client):
    payload = sample_payload()
    payload["recipients"][0]["email"] = "not-an-email"
    response = client.post("/jobs", json=payload)
    assert response.status_code == 422


def test_job_status_and_certificate_retrieval(client):
    response = client.post("/jobs", json=sample_payload())
    job_id = response.json()["job_id"]

    result = wait_for_completion(client, job_id)
    assert result["successful"] == 2
    assert result["failed"] == 0
    assert result["progress_percent"] == 100.0

    certificate_id = result["recipients"][0]["certificate_id"]
    download = client.get(f"/certificates/{certificate_id}")
    assert download.status_code == 200
    assert download.headers["content-type"] == "application/pdf"


def test_missing_job(client):
    response = client.get("/jobs/does-not-exist")
    assert response.status_code == 404
