from datetime import datetime

from sqlalchemy.orm import Session

from ..database import SessionLocal
from ..models import Certificate, GenerationJob, JobStatus, Recipient, RecipientStatus
from .certificate_generator import generate_certificate


def process_job(job_id: str) -> None:
    """Process every recipient independently so one failure does not stop the batch."""
    db: Session = SessionLocal()
    try:
        job = db.get(GenerationJob, job_id)
        if not job:
            return

        job.status = JobStatus.PROCESSING
        db.commit()

        for recipient in job.recipients:
            recipient.status = RecipientStatus.PROCESSING
            db.commit()

            try:
                certificate_id = __import__("uuid").uuid4()
                path = generate_certificate(
                    certificate_id=str(certificate_id),
                    recipient_name=recipient.name,
                    certificate_title=recipient.certificate_title,
                    event_name=job.event_name,
                    event_date=job.event_date,
                )

                db.add(
                    Certificate(
                        id=str(certificate_id),
                        recipient_id=recipient.id,
                        file_path=path,
                    )
                )
                recipient.status = RecipientStatus.SUCCESS
                job.success_count += 1
                db.commit()

            except Exception as exc:
                # Failure is isolated to this recipient.
                db.rollback()
                recipient = db.get(Recipient, recipient.id)
                recipient.status = RecipientStatus.FAILED
                recipient.error_message = str(exc)
                job.failed_count += 1
                db.commit()

        job.status = (
            JobStatus.COMPLETED_WITH_ERRORS
            if job.failed_count
            else JobStatus.COMPLETED
        )
        job.completed_at = datetime.utcnow()
        db.commit()

    except Exception:
        db.rollback()
        job = db.get(GenerationJob, job_id)
        if job:
            job.status = JobStatus.FAILED
            job.completed_at = datetime.utcnow()
            db.commit()
    finally:
        db.close()
