from fastapi import FastAPI

from .database import Base, engine
from .api.jobs import router as jobs_router
from .api.certificates import router as certificates_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Bulk Certificate Generator",
    version="1.0.0",
    description="Bulk certificate generation API using FastAPI and ReportLab.",
)

app.include_router(jobs_router)
app.include_router(certificates_router)


@app.get("/health")
def health():
    return {"status": "ok"}
