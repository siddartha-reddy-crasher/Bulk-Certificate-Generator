The predefined certificate template is implemented in app/services/certificate_generator.py using ReportLab.
