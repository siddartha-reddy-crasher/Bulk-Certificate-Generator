from datetime import date
from pydantic import BaseModel, EmailStr, Field, field_validator


class RecipientInput(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    certificate_title: str = Field(
        default="Certificate of Participation",
        min_length=2,
        max_length=255,
    )

    @field_validator("name", "certificate_title")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be empty")
        return value


class GenerationJobCreate(BaseModel):
    event_name: str = Field(..., min_length=2, max_length=255)
    event_date: date
    recipients: list[RecipientInput] = Field(..., min_length=1, max_length=5000)

    @field_validator("event_name")
    @classmethod
    def strip_event_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Event name cannot be empty")
        return value


class RecipientStatusResponse(BaseModel):
    id: str
    name: str
    email: str
    status: str
    error_message: str | None = None
    certificate_id: str | None = None


class JobResponse(BaseModel):
    job_id: str
    status: str
    total: int
    completed: int
    successful: int
    failed: int
    progress_percent: float
    recipients: list[RecipientStatusResponse] | None = None
