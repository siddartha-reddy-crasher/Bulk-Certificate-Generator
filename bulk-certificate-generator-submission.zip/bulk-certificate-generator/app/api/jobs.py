from concurrent.futures import ThreadPoolExecutor

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import GenerationJob, Recipient
from ..schemas import GenerationJobCreate, JobResponse, RecipientStatusResponse
from ..services.job_processor import process_job

router = APIRouter(prefix="/jobs", tags=["Jobs"])
executor = ThreadPoolExecutor(max_workers=4)


def build_job_response(job: GenerationJob, include_recipients: bool = True) -> JobResponse:
    completed = job.success_count + job.failed_count
    progress = round((completed / job.total_count) * 100, 2) if job.total_count else 0

    recipients = None
    if include_recipients:
        recipients = [
            RecipientStatusResponse(
                id=r.id,
                name=r.name,
                email=r.email,
                status=r.status.value,
                error_message=r.error_message,
                certificate_id=r.certificate.id if r.certificate else None,
            )
            for r in job.recipients
        ]

    return JobResponse(
        job_id=job.id,
        status=job.status.value,
        total=job.total_count,
        completed=completed,
        successful=job.success_count,
        failed=job.failed_count,
        progress_percent=progress,
        recipients=recipients,
    )


@router.post("", response_model=JobResponse, status_code=202)
def create_job(payload: GenerationJobCreate, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    job = GenerationJob(
        event_name=payload.event_name,
        event_date=payload.event_date.isoformat(),
        total_count=len(payload.recipients),
    )
    db.add(job)
    db.flush()

    for item in payload.recipients:
        db.add(
            Recipient(
                job_id=job.id,
                name=item.name,
                email=str(item.email),
                certificate_title=item.certificate_title,
            )
        )

    db.commit()
    db.refresh(job)

    # FastAPI BackgroundTasks keeps the request responsive for bulk jobs.
    background_tasks.add_task(process_job, job.id)
    return build_job_response(job)


@router.get("/{job_id}", response_model=JobResponse)
def get_job(job_id: str, db: Session = Depends(get_db)):
    job = db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return build_job_response(job)
