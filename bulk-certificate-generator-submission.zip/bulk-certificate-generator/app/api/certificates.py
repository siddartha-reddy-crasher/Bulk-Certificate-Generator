from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Certificate

router = APIRouter(prefix="/certificates", tags=["Certificates"])


@router.get("/{certificate_id}")
def download_certificate(certificate_id: str, db: Session = Depends(get_db)):
    certificate = db.get(Certificate, certificate_id)
    if not certificate:
        raise HTTPException(status_code=404, detail="Certificate not found")

    path = Path(certificate.file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Certificate file not found")

    return FileResponse(
        path=path,
        media_type="application/pdf",
        filename=f"certificate-{certificate_id}.pdf",
    )
